import { useState } from "react";
import { useDrag } from "react-dnd";

function TaskCard({ task, updateMutation, deleteMutation }) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: "TASK",
    item: { id: task.id, category: task.category },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }));

  // State for Editing Mode & Delete Confirmation
  const [isEditing, setIsEditing] = useState(false);
  const [editedTask, setEditedTask] = useState({
    title: task.title || "",
    description: task.description || "",
    deadline: task.deadline || "",
    category: task.category || "General",
    priority: task.priority || "Medium",
  });

  const [showConfirm, setShowConfirm] = useState(false);

  // Handle Save Changes
  const handleSave = () => {
    const updatedTask = {
      ...editedTask,
      deadline: editedTask.deadline ? editedTask.deadline : null,
    };

    updateMutation.mutate({ taskId: task.id, updates: updatedTask });
    setIsEditing(false);
  };

  return (
    <div
      ref={drag}
      className={`task-card ${task.category.toLowerCase()} ${
        isDragging ? "opacity-50" : "opacity-100"
      }`}
    >
      {isEditing ? (
        // Editable Fields
        <div className="space-y-2">
          <input
            type="text"
            value={editedTask.title}
            onChange={(e) =>
              setEditedTask({ ...editedTask, title: e.target.value || "" })
            }
            className="w-full p-2 border rounded"
          />
          <textarea
            value={editedTask.description}
            onChange={(e) =>
              setEditedTask({
                ...editedTask,
                description: e.target.value || "",
              })
            }
            className="w-full p-2 border rounded"
          />
          <select
            value={editedTask.category}
            onChange={(e) =>
              setEditedTask({ ...editedTask, category: e.target.value })
            }
            className="w-full p-2 border rounded"
          >
            <option value="General">General</option>
            <option value="Work">Work</option>
            <option value="Personal">Personal</option>
            <option value="Urgent">Urgent</option>
          </select>
          <select
            value={editedTask.priority}
            onChange={(e) =>
              setEditedTask({ ...editedTask, priority: e.target.value })
            }
            className="w-full p-2 border rounded"
          >
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
          <input
            type="date"
            value={editedTask.deadline}
            onChange={(e) =>
              setEditedTask({ ...editedTask, deadline: e.target.value || "" })
            }
            className="w-full p-2 border rounded"
          />
          <button
            onClick={handleSave}
            className="bg-green-500 text-white px-4 py-1 rounded hover:bg-green-600 transition-all"
          >
            💾 Save
          </button>
          <button
            onClick={() => setIsEditing(false)}
            className="bg-gray-500 text-white px-4 py-1 rounded hover:bg-gray-600 transition-all"
          >
            ❌ Cancel
          </button>
        </div>
      ) : (
        // Task Display
        <div>
          <h3 className="text-xl font-bold">{task.title}</h3>
          <p className="text-gray-600">{task.description}</p>
          <p className="text-gray-500">
            📌 Category: <strong>{task.category}</strong>
          </p>
          <p className="text-gray-500">
            ⚡ Priority: <strong>{task.priority}</strong>
          </p>
          <p className="text-gray-500">
            🗓️ Deadline:{" "}
            {task.deadline ? task.deadline.split("T")[0] : "No Deadline"}
          </p>
          <p className="text-gray-500">
            ⏰ Time:{" "}
            {task.deadline
              ? task.deadline.split("T")[1]?.slice(0, 5)
              : "No Time"}
          </p>

          {/* Show Download Link if a File Exists */}
          {task.file && (
            <a
              href={`http://localhost:5000${task.file}`}
              download
              className="download-link"
            >
              📎 Download File
            </a>
          )}

          <div className="task-buttons">
            <button
              onClick={() => setIsEditing(true)}
              className="bg-yellow-500 text-white px-4 py-1 rounded hover:bg-yellow-600 transition-all"
            >
              ✏️ Edit
            </button>

            {/* Restore Button for Completed Tasks */}
            {task.status === "completed" ? (
              <button
                onClick={() =>
                  updateMutation.mutate({
                    taskId: task.id,
                    updates: { status: "pending" },
                  })
                }
                className="bg-blue-500 text-white px-4 py-1 rounded hover:bg-blue-600 transition-all"
              >
                🔄 Restore
              </button>
            ) : (
              <button
                onClick={() =>
                  updateMutation.mutate({
                    taskId: task.id,
                    updates: { status: "completed" },
                  })
                }
                className="bg-green-500 text-white px-4 py-1 rounded hover:bg-green-600 transition-all"
              >
                ✅ Complete
              </button>
            )}

            {/* Delete Button */}
            <button
              onClick={() => setShowConfirm(true)}
              className="bg-red-500 text-white px-4 py-1 rounded hover:bg-red-600 transition-all"
            >
              ❌ Delete
            </button>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {showConfirm && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-5 rounded-lg shadow-lg">
            <h3 className="text-xl font-bold mb-2">⚠️ Confirm Delete</h3>
            <p>
              Are you sure you want to delete <strong>{task.title}</strong>?
            </p>
            <div className="mt-4 flex gap-3">
              <button
                onClick={() => {
                  deleteMutation.mutate(task.id);
                  setShowConfirm(false);
                }}
                className="bg-red-500 text-white px-4 py-1 rounded hover:bg-red-600 transition-all"
              >
                Yes, Delete
              </button>
              <button
                onClick={() => setShowConfirm(false)}
                className="bg-gray-500 text-white px-4 py-1 rounded hover:bg-gray-600 transition-all"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default TaskCard;
