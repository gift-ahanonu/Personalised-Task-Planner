import { Bar, Doughnut } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement } from "chart.js";

// Register the necessary chart components
ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement);

function TaskAnalytics({ tasks }) {
  // Calculate Completed vs Pending Tasks
  const completedTasks = tasks.filter(task => task.status === "completed").length;
  const pendingTasks = tasks.length - completedTasks;

  // Category-wise Task Count
  const categoryCounts = {
    General: tasks.filter(task => task.category === "General").length,
    Work: tasks.filter(task => task.category === "Work").length,
    Personal: tasks.filter(task => task.category === "Personal").length,
    Urgent: tasks.filter(task => task.category === "Urgent").length,
  };

  return (
    <div className="analytics-container">
      <h2>📊 Task Progress </h2>
<br/>

      {/* Task Completion Progress Bar */}
      <div className="progress-bar">
        <div
          className="progress"
          style={{ width: `${(completedTasks / tasks.length) * 100 || 0}%` }}
        ></div>
      </div>
      <p>{completedTasks} out of {tasks.length} tasks completed</p>

      {/* Doughnut Chart for Task Completion */}
      <div className="chart-container">
        <Doughnut
          data={{
            labels: ["Completed", "Pending"],
            datasets: [
              {
                data: [completedTasks, pendingTasks],
                backgroundColor: ["#4CAF50", "#FF5733"],
              },
            ],
          }}
        />
      </div>

      {/* Bar Chart for Category-based Task Count */}
      <div className="chart-container">
        <Bar
          data={{
            labels: Object.keys(categoryCounts),
            datasets: [
              {
                label: "Tasks per Category",
                data: Object.values(categoryCounts),
                backgroundColor: ["#6c757d", "#007bff", "#28a745", "#d32f2f"],
              },
            ],
          }}
        />
      </div>
    </div>
  );
}

export default TaskAnalytics;
