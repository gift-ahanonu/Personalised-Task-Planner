import "./index.css";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { useState } from "react";
import Login from "./Login";
import Register from "./Register";
import TaskManager from "./TaskManager";

function App() {
  const [token, setToken] = useState(localStorage.getItem("jwt") || "");
  const [showRegister, setShowRegister] = useState(false);

  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={token ? <TaskManager token={token} /> : <Navigate to="/login" />}
        />
        <Route path="/login" element={<Login setToken={setToken} />} />
        <Route path="/register" element={<Register setToken={setToken} />} />
      </Routes>
    </Router>
  );
}

export default App;
