import { useDrag } from "react-dnd";

function Task({ task, updateMutation, deleteMutation }) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: "TASK",
    item: { id: task.id, category: task.category },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }));

  return (
    <div
      ref={drag}
      className={`p-4 border rounded mt-2 bg-gray-100 transition-transform transform hover:scale-105 ${
        isDragging ? "opacity-50" : "opacity-100"
      }`}
    >
      <h3 className="text-xl font-bold">{task.title}</h3>
      <p className="text-gray-600">{task.description}</p>
      <p className="text-gray-500">Priority: {task.priority}</p>
      <p className="text-gray-500">Deadline: {task.deadline.split("T")[0]}</p>

      {/* Pass task ID */}
      <div className="mt-2 flex gap-2">
        <button
          onClick={() =>
            updateMutation.mutate({
              taskId: task.id,
              updates: { status: "completed" },
            })
          }
          className="bg-green-500 text-white px-4 py-1 rounded hover:bg-green-600 transition-all"
        >
          ✅ Complete
        </button>
        <button
          onClick={() => deleteMutation.mutate(task.id)}
          className="bg-red-500 text-white px-4 py-1 rounded hover:bg-red-600 transition-all"
        >
          ❌ Delete
        </button>
      </div>
    </div>
  );
}

export default Task;
