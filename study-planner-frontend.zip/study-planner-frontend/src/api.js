const API_URL = "http://localhost:5000"; 

// Fetch Tasks
export const fetchTasks = async (token) => {
  const response = await fetch(`${API_URL}/tasks/all`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!response.ok) {
    throw new Error(`${response.status} - ${await response.text()}`);
  }

  return response.json();
};

// Add Task
export const addTask = async (token, task) => {
  const response = await fetch("http://localhost:5000/tasks/create", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(task),
  });

  if (!response.ok) {
    throw new Error(`Error adding task: ${response.statusText}`);
  }

  return response.json();
};


// Update Task
export const updateTask = async (token, taskId, updates) => {
  const response = await fetch(`${API_URL}/tasks/update/${taskId}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      ...updates,
      deadline: updates.deadline ? updates.deadline : null, 
    }),
  });

  if (!response.ok) {
    throw new Error(`Error: ${response.status} - ${await response.text()}`);
  }

  return response.json();
};

// Delete Task
export const deleteTask = async (token, taskId) => {
  const response = await fetch(`${API_URL}/tasks/delete/${taskId}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!response.ok) {
    throw new Error(`${response.status} - ${await response.text()}`);
  }

  return response.json();
};

// Login User
export const loginUser = async (email, password) => {
  const response = await fetch(`${API_URL}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });

  if (!response.ok) {
    throw new Error(`${response.status} - ${await response.text()}`);
  }

  return response.json();
};

// Register User
export const registerUser = async (username, email, password) => {
  const response = await fetch(`${API_URL}/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, email, password }),
  });

  if (!response.ok) {
    throw new Error(`${response.status} - ${await response.text()}`);
  }

  return response.json(); 
};


export const deleteAccount = async (token) => {
  const response = await fetch(`${API_URL}/auth/delete`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!response.ok) {
    throw new Error(`${response.status} - ${await response.text()}`);
  }

  return response.json();
};


export const uploadFile = async (token, file) => {
  const formData = new FormData();
  formData.append("file", file);

  const response = await fetch("http://localhost:5000/tasks/upload", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,  // ✅ Ensure token is included
    },
    body: formData,
  });

  if (!response.ok) {
    throw new Error(`File upload failed: ${response.status} - ${await response.text()}`);
  }

  return response.json();
};
