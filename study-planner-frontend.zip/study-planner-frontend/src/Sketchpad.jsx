import "./Sketchpad.css";
import { useEffect, useRef, useState } from "react";
import paper from "paper";

function Sketchpad() {
  const canvasRef = useRef(null);
  const [history, setHistory] = useState([]);
  const [redoStack, setRedoStack] = useState([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) {
      console.error("❌ Canvas not found!");
      return;
    }

    paper.setup(canvas);
    const background = new paper.Path.Rectangle({
      point: [0, 0],
      size: paper.view.size,
      fillColor: "white", // Set White Background
    });
    background.sendToBack(); // This ensures it stays behind drawings

    let path;
    const tool = new paper.Tool();

    tool.onMouseDown = (event) => {
      path = new paper.Path();
      path.strokeColor = "black";
      path.strokeWidth = 3;
      path.add(event.point);
    };

    tool.onMouseDrag = (event) => {
      path.add(event.point);
    };

    tool.onMouseUp = () => {
      if (path) {
        setHistory((prev) => [...prev, path]);
        setRedoStack([]);
      }
    };

    return () => {
      paper.project.clear();
    };
  }, []);

  // Undo Last Action
  const handleUndo = () => {
    if (history.length > 0) {
      const lastPath = history.pop();
      setRedoStack((prev) => [...prev, lastPath]);
      lastPath.remove();
      setHistory([...history]);
      paper.view.update();
    }
  };

  // Redo Last Undone Action
  const handleRedo = () => {
    if (redoStack.length > 0) {
      const restoredPath = redoStack.pop();
      setHistory((prev) => [...prev, restoredPath]);
      paper.project.activeLayer.addChild(restoredPath);
      setRedoStack([...redoStack]);
      paper.view.update();
    }
  };

  // Clear Sketchpad
  const handleClear = () => {
    paper.project.clear();
    setHistory([]);
    setRedoStack([]);

    // Reapply White Background
    const background = new paper.Path.Rectangle({
      point: [0, 0],
      size: paper.view.size,
      fillColor: "white",
    });
    background.sendToBack();
  };

  // Download Sketch as JPEG file
  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) {
      console.error("❌ No canvas found!");
      return;
    }

    const link = document.createElement("a");
    link.href = canvas.toDataURL("image/jpeg", 1.0); // Save as JPEG
    link.download = `sketch-${Date.now()}.jpg`;
    link.click();
  };

  return (
    <div className="sketchpad-container">
      <h2>📝 Sketchpad</h2>
      <canvas ref={canvasRef} className="sketchpad-canvas" />

      <div className="button-container">
        <button onClick={handleUndo} className="action-btn">
          ↩️ Undo
        </button>
        <button onClick={handleRedo} className="action-btn">
          ↪️ Redo
        </button>
        <button onClick={handleClear} className="danger-btn">
          🗑️ Clear
        </button>
        <button onClick={handleDownload} className="save-btn">
          💾 Download
        </button>
      </div>
    </div>
  );
}

export default Sketchpad;
