import { useState, useEffect } from "react";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import "react-big-calendar/lib/css/react-big-calendar.css";
import "./CalendarStyles.css";

const localizer = momentLocalizer(moment);

function CalendarComponent({ tasks, addTask }) {
  const [events, setEvents] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [newTask, setNewTask] = useState({
    title: "",
    deadline: null,
    description: "",
    category: "General",
    priority: "Medium",
    file: null,
  });

  useEffect(() => {
    const formattedEvents = tasks.map((task) => {
      const taskDate = new Date(task.deadline);

      return {
        id: task.id,
        title: task.title,
        start: taskDate,
        end: new Date(taskDate.getTime() + 60 * 60 * 1000),
        status: task.status,
      };
    });

    setEvents(formattedEvents);
  }, [tasks]);

  // Task Color Logic: Pending --> Red, Completed --> Green)
  const eventStyleGetter = (event) => {
    let backgroundColor = event.status === "completed" ? "#22c55e" : "#ef4444";
    return {
      style: {
        backgroundColor,
        color: "white",
        borderRadius: "5px",
        padding: "5px",
      },
    };
  };

  // Handle Clicking on a Calendar Day
  const handleSelectSlot = ({ start }) => {
    setNewTask({ ...newTask, deadline: start });
    setShowModal(true);
  };

  // Handle File Upload
  const handleFileUpload = (e) => {
    setSelectedFile(e.target.files[0]);
  };

  // Handle Adding New Task
  const handleAddTask = () => {
    if (newTask.title) {
      const taskData = { ...newTask, file: selectedFile };
      addTask(taskData); // Send task to TaskManager
      setShowModal(false);
    }
  };

  return (
    <div className="calendar-container">
      <h2 className="calendar-title">📅 Task Calendar</h2>
      <Calendar
        localizer={localizer}
        events={events}
        startAccessor="start"
        endAccessor="end"
        selectable
        onSelectSlot={handleSelectSlot}
        style={{ height: "90vh", width: "100%" }}
        eventPropGetter={eventStyleGetter}
      />

      {/* Full Task Creation Modal */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h3>Add Task</h3>
            <input
              type="text"
              placeholder="Task Title"
              value={newTask.title}
              onChange={(e) =>
                setNewTask({ ...newTask, title: e.target.value })
              }
              className="input-field"
            />
            <textarea
              placeholder="Task Description"
              value={newTask.description}
              onChange={(e) =>
                setNewTask({ ...newTask, description: e.target.value })
              }
              className="input-field"
            />
            <p>📅 Date: {moment(newTask.deadline).format("MMMM Do YYYY")}</p>
            <input
              type="time"
              value={moment(newTask.deadline).format("HH:mm")}
              onChange={(e) =>
                setNewTask({
                  ...newTask,
                  deadline: moment(newTask.deadline)
                    .set("hour", e.target.value.split(":")[0])
                    .set("minute", e.target.value.split(":")[1])
                    .toDate(),
                })
              }
              className="input-field"
            />
            <select
              value={newTask.category}
              onChange={(e) =>
                setNewTask({ ...newTask, category: e.target.value })
              }
              className="input-field"
            >
              <option value="General">General</option>
              <option value="Work">Work</option>
              <option value="Personal">Personal</option>
              <option value="Urgent">Urgent</option>
            </select>
            <select
              value={newTask.priority}
              onChange={(e) =>
                setNewTask({ ...newTask, priority: e.target.value })
              }
              className="input-field"
            >
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </select>
            <input
              type="file"
              onChange={handleFileUpload}
              className="input-field"
            />

            <button onClick={handleAddTask} className="btn-save">
              Save Task
            </button>
            <button onClick={() => setShowModal(false)} className="btn-cancel">
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default CalendarComponent;
