import { useState } from "react";
import { useNavigate } from "react-router-dom";

const API_URL = "http://localhost:5000";

function Login({ setToken }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate(); //

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const response = await fetch(`${API_URL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Failed to log in");
      }

      localStorage.setItem("jwt", data.token);
      setToken(data.token);

      navigate("/");
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <div>
      <div className="auth-container">
        <h1 className="h1Title">📌FocusHub </h1>
        <h2 className="auth-title">🔑 Login</h2>
        {error && <p className="error-text">{error}</p>}
        <form onSubmit={handleLogin} className="space-y-4">
          <input
            type="email"
            placeholder="Email"
            className="input-field"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            className="input-field"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="submit" className="primary-btn">
            🔓 Log In
          </button>
          <br />
          <br />
          <span>
            <a href="">Forgot Password?</a>
          </span>
          <br />

          <p className="text-center mt-3">
            Don't have an account?{" "}
            <button className="link-btn" onClick={() => navigate("/register")}>
              Register here
            </button>
          </p>
        </form>
      </div>
    </div>
  );
}

export default Login;
