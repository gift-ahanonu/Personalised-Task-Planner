import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  fetchTasks,
  addTask,
  updateTask,
  deleteTask,
  loginUser,
  registerUser,
} from "./api";
import { DndProvider, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import TaskAnalytics from "./TaskAnalytics";
import TaskCard from "./TaskCard";
import CalendarComponent from "./CalendarComponent";
import Sketchpad from "./Sketchpad";

// Define the TaskManager function
function TaskManager() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [token, setToken] = useState(localStorage.getItem("jwt") || "");
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    deadline: "",
    time: "",
    category: "",
    priority: "",
  });
  const [isLoggedIn, setIsLoggedIn] = useState(!!token);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isRegistering, setIsRegistering] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [activeSection, setActiveSection] = useState("analytics");
  const [completedTasks, setCompletedTasks] = useState([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth > 768);
  const [selectedFile, setSelectedFile] = useState(null);
  const [user, setUser] = useState(null);
  const [newUsername, setNewUsername] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  console.log("🔑 Token being used:", token);

  const handleAddTask = async () => {
    if (!newTask.title) {
      console.error("❌ Task title is required!");
      return;
    }

    let uploadedFilePath = null;
    if (selectedFile) {
      const formData = new FormData();
      formData.append("file", selectedFile);

      try {
        const uploadResponse = await fetch(
          "http://localhost:5000/tasks/upload",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${token}`,
            },
            body: formData,
          }
        );

        if (!uploadResponse.ok) {
          throw new Error(
            `File upload failed! Status: ${uploadResponse.status}`
          );
        }

        const uploadData = await uploadResponse.json();
        console.log("✅ File Uploaded:", uploadData.filePath);
        uploadedFilePath = uploadData.filePath;
      } catch (error) {
        console.error("❌ Error uploading file:", error);
        return;
      }
    }

    try {
      await addMutation.mutateAsync({ ...newTask, file: uploadedFilePath });

      queryClient.invalidateQueries(["tasks"]);

      console.log("✅ Task Added Successfully!");
      setNewTask({
        title: "",
        description: "",
        deadline: "",
        category: "General",
        priority: "Medium",
        file: null,
      });
      setSelectedFile(null);
    } catch (error) {
      console.error("❌ Error adding task:", error);
    }
  };

  const handleFileUpload = async () => {
    if (!selectedFile) {
      console.error("❌ No file selected!");
      return;
    }

    const formData = new FormData();
    formData.append("file", selectedFile);

    try {
      const response = await fetch("http://localhost:5000/tasks/upload", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error("File upload failed!");
      }

      const data = await response.json();
      console.log("✅ File Uploaded:", data.filePath);

      setNewTask((prev) => ({ ...prev, file: data.filePath }));
    } catch (error) {
      console.error("❌ Error uploading file:", error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("jwt");
    setToken("");
    setIsLoggedIn(false);
    navigate("/login");
  };

  // Fetch tasks automatically when logged in
  const { data: tasks = [], isLoading } = useQuery({
    queryKey: ["tasks", token],
    queryFn: () => fetchTasks(token),
    enabled: !!token,
  });

  // Add Task
  const addMutation = useMutation({
    mutationFn: async (task) => {
      console.log("🚀 Adding Task:", task);

      let uploadedFilePath = null;
      if (task.file) {
        const formData = new FormData();
        formData.append("file", task.file);

        const uploadResponse = await fetch(
          "http://localhost:5000/tasks/upload",
          {
            method: "POST",
            body: formData,
          }
        );

        const uploadData = await uploadResponse.json();
        uploadedFilePath = uploadData.filePath;
      }

      return addTask(token, {
        ...task,
        file: uploadedFilePath, // Attach the uploaded file path
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["tasks"]);
      setNewTask({
        title: "",
        description: "",
        deadline: "",
        category: "General",
        priority: "Medium",
        file: null,
      });
    },
    onError: (error) => {
      console.error("Error adding task:", error);
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ taskId, updates }) => {
      console.log(`🟢 Updating Task ${taskId} with`, updates);

      let uploadedFilePath = updates.file || null;

      if (updates.file instanceof File) {
        const formData = new FormData();
        formData.append("file", updates.file);

        const uploadResponse = await fetch(
          "http://localhost:5000/tasks/upload",
          {
            method: "POST",
            body: formData,
          }
        );

        const uploadData = await uploadResponse.json();
        uploadedFilePath = uploadData.filePath;
      }

      await updateTask(token, taskId, { ...updates, file: uploadedFilePath });
    },

    onMutate: async ({ taskId, updates }) => {
      await queryClient.cancelQueries(["tasks"]);

      // Ensure tasks exist
      const previousTasks = queryClient.getQueryData(["tasks"]) || [];

      // Update the UI before backend confirms the move
      queryClient.setQueryData(["tasks"], (oldTasks = []) =>
        oldTasks.map((task) =>
          task.id === taskId
            ? { ...task, ...updates, file: updates.file || task.file }
            : task
        )
      );

      console.log(`Updated Task ${taskId} to`, updates);

      return { previousTasks };
    },

    onError: (err, variables, context) => {
      console.error("❌ Error updating task:", err);
      if (context && context.previousTasks) {
        queryClient.setQueryData(["tasks"], context.previousTasks);
      }
    },

    onSettled: async () => {
      console.log("🔄 Refetching tasks after update...");
      await queryClient.invalidateQueries(["tasks"]);
    },
  });

  // Move Task Between Categories (Drag & Drop)
  const moveTaskMutation = useMutation({
    mutationFn: async ({ taskId, updates }) => {
      console.log(`🟢 Updating Task ${taskId} with`, updates);

      //Ensure deadline is null if empty
      const updatedData = {
        ...updates,
        deadline: updates.deadline ? updates.deadline : null,
      };

      await updateTask(token, taskId, updatedData);
    },

    onMutate: async ({ taskId, newCategory }) => {
      await queryClient.cancelQueries(["tasks"]);

      const previousTasks = queryClient.getQueryData(["tasks"]) || [];

      queryClient.setQueryData(["tasks"], (oldTasks = []) =>
        oldTasks.map((task) =>
          task.id === taskId ? { ...task, category: newCategory } : task
        )
      );

      console.log(
        ` Task ${taskId} moved to ${newCategory} (Optimistic Update)`
      );

      return { previousTasks };
    },

    onError: (err, variables, context) => {
      console.error("❌ Error moving task:", err);

      // Ensure previousTasks exists before restoring
      if (context && context.previousTasks) {
        queryClient.setQueryData(["tasks"], context.previousTasks);
      }
    },

    onSettled: async () => {
      console.log("🔄 Refetching tasks after move...");
      await queryClient.invalidateQueries(["tasks"]);
    },
  });

  // Delete Task
  const deleteMutation = useMutation({
    mutationFn: (taskId) => deleteTask(token, taskId),
    onSuccess: () => queryClient.invalidateQueries(["tasks"]),
  });

  const deleteAccount = async () => {
    try {
      const response = await fetch("http://localhost:5000/auth/delete", {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error("Failed to delete account");
      }

      // Clear local storage & logout
      localStorage.removeItem("jwt");
      setToken("");
      setIsLoggedIn(false);
      navigate("/login"); // Redirect to login page

      console.log("✅ Account deleted successfully!");
    } catch (error) {
      console.error("❌ Error deleting account:", error);
    }
  };

  // Fetch User Info on Load
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await fetch("http://localhost:5000/auth/me", {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch user data");
        }

        const data = await response.json();
        setUser(data);
      } catch (error) {
        console.error("❌ Error fetching user:", error);
      }
    };

    if (token) fetchUser(); // Fetch user only if logged in
  }, [token]);

  //Log user data to console
  useEffect(() => {
    console.log("🟢 User Data:", user);
  }, [user]);

  const handleChangeUsername = async () => {
    try {
      const response = await fetch(
        "http://localhost:5000/auth/update-username",
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ newUsername }),
        }
      );

      if (!response.ok) throw new Error("Failed to update username");
      alert("✅ Username updated successfully!");
      setUser({ ...user, username: newUsername });
    } catch (error) {
      console.error("❌ Error updating username:", error);
    }
  };

  //  Handle Password Change
  const handleChangePassword = async () => {
    try {
      const response = await fetch(
        "http://localhost:5000/auth/update-password",
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ currentPassword, newPassword }),
        }
      );

      if (!response.ok) throw new Error("Failed to update password");
      alert("✅ Password updated successfully!");
    } catch (error) {
      console.error("❌ Error updating password:", error);
    }
  };

  // Handle Account Deletion
  const handleDeleteAccount = async () => {
    try {
      await deleteAccount(token);
      localStorage.removeItem("jwt"); // Remove token
      setToken(""); // Clear session
      setIsLoggedIn(false);
      navigate("/register"); // Redirect to register after account deletion
    } catch (error) {
      console.error("❌ Error deleting account:", error);
    }
    deleteAccount();
    setShowDeleteModal(false);
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="app-container">
        {/* Sidebar Navigation */}
        <aside className={`sidebar ${isSidebarOpen ? "open" : "collapsed"}`}>
          {/* Hamburger Menu Button */}
          <button
            className="sidebar-toggle"
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          >
            ☰ {/* Hamburger Icon */}
          </button>

          {isSidebarOpen && (
            <>
              <h1 className="sidebar-title">📌 FocusHub</h1>
              <nav className="sidebar-nav">
                <button
                  className="sidebar-btn"
                  onClick={() => setActiveSection("analytics")}
                >
                  📊 My Progress
                </button>
                <button
                  className="sidebar-btn"
                  onClick={() => setActiveSection("tasks")}
                >
                  📋 Tasks to do
                </button>
                <button
                  className="sidebar-btn"
                  onClick={() => setActiveSection("calendar")}
                >
                  📅 Calendar
                </button>
                <button
                  className="sidebar-btn"
                  onClick={() => setActiveSection("sketchpad")}
                >
                  📝 Sketchpad
                </button>
                <button
                  className="sidebar-btn"
                  onClick={() => setActiveSection("completed")}
                >
                  ✅ Completed Tasks
                </button>
                <button
                  className="sidebar-btn"
                  onClick={() => setActiveSection("settings")}
                >
                  ⚙️ Settings
                </button>
              </nav>
              <button
                onClick={() => {
                  localStorage.removeItem("jwt");
                  setToken("");
                  setIsLoggedIn(false);
                  navigate("/login");
                }}
                className="logout-btn"
              >
                Logout
              </button>
            </>
          )}
        </aside>

        {/*  Main Content  */}
        <main
          className={`main-content ${isSidebarOpen ? "expanded" : "collapsed"}`}
        >
          {activeSection === "analytics" && (
            <div className="analytics-page">
              <TaskAnalytics tasks={tasks} />
            </div>
          )}

          {/* Show Tasks Only When "Dashboard" is Clicked */}
          {activeSection === "tasks" && (
            <>
              {" "}
              <h1 className="h1Title">📌FocusHub </h1>
              {/* Search Section */}
              <div className="filter-section">
                <input
                  type="text"
                  placeholder="Search tasks..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="input-field"
                />
              </div>
              {/* Add Task Form */}
              <div className="task-form">
                <input
                  type="text"
                  placeholder="Task Title"
                  value={newTask.title || ""}
                  onChange={(e) =>
                    setNewTask({ ...newTask, title: e.target.value })
                  }
                  className="input-field"
                />
                <textarea
                  placeholder="Task Description"
                  value={newTask.description || ""}
                  onChange={(e) =>
                    setNewTask({ ...newTask, description: e.target.value })
                  }
                  className="input-field"
                />

                {/* Date Input */}
                <input
                  type="date"
                  value={newTask.deadline || ""}
                  onChange={(e) =>
                    setNewTask({ ...newTask, deadline: e.target.value })
                  }
                  className="input-field"
                />

                {/* Time Input */}
                <input
                  type="time"
                  value={newTask.time || ""}
                  onChange={(e) =>
                    setNewTask({ ...newTask, time: e.target.value })
                  }
                  className="input-field"
                />

                {/* Category Selection */}
                <select
                  value={newTask.category || ""}
                  onChange={(e) =>
                    setNewTask({ ...newTask, category: e.target.value })
                  }
                  className="input-field"
                >
                  <option value="General">General</option>
                  <option value="Work">Work</option>
                  <option value="Personal">Personal</option>
                  <option value="Urgent">Urgent</option>
                </select>

                {/* Priority Selection */}
                <select
                  value={newTask.priority || ""}
                  onChange={(e) =>
                    setNewTask({ ...newTask, priority: e.target.value })
                  }
                  className="input-field"
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                </select>

                {/* File Upload */}
                <input
                  type="file"
                  onChange={(e) => setSelectedFile(e.target.files[0])}
                  className="input-field"
                />

                {/* Add Task Button */}
                <button
                  onClick={handleAddTask} // ✅ Use this function to upload & add task
                  className="primary-btn"
                >
                  ➕ Add Task
                </button>
              </div>
              {/* Drag & Drop Task Categories */}
              {["Urgent", "Work", "Personal", "General"].map((category) => {
                // Define colors for each category
                const categoryColors = {
                  Urgent: "#dc3545", // Red
                  Work: "#007bff", // Blue
                  Personal: "#28a745", // Green
                  General: "#6c757d", // Gray
                };

                return (
                  <div key={category} className="category-section">
                    {/* Dynamic Category Title with Different Colors */}
                    <h3
                      className="category-title"
                      style={{ backgroundColor: categoryColors[category] }}
                    >
                      {category} Tasks
                    </h3>

                    {/* Display Tasks for Each Category */}
                    {tasks
                      .filter((task) => task.category === category)
                      .filter((task) => task.status !== "completed") // Hide completed tasks
                      .map((task) => (
                        <TaskCard
                          key={task.id}
                          task={task}
                          updateMutation={updateMutation}
                          deleteMutation={deleteMutation}
                        />
                      ))}
                  </div>
                );
              })}
            </>
          )}

          {/* Show Only Completed Tasks When "Completed" section is Clicked */}
          {activeSection === "completed" && (
            <div className="completed-tasks">
              <h1 className="completed-title">✅ Completed Tasks</h1>

              {/* Search & Filter Section for Completed Tasks */}
              <div className="filter-section">
                <input
                  type="text"
                  placeholder="Search completed tasks..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="input-field"
                />
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="input-field"
                >
                  <option value="all">All Completed</option>
                  <option value="high">High Priority</option>
                  <option value="medium">Medium Priority</option>
                  <option value="low">Low Priority</option>
                </select>
              </div>

              {/* Filter & Display Completed Tasks */}
              {tasks
                .filter((task) => task.status === "completed")
                .filter(
                  (task) =>
                    task.title
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase()) ||
                    task.category
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase()) ||
                    task.priority
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase())
                )
                .filter((task) =>
                  statusFilter === "all"
                    ? true
                    : task.priority.toLowerCase() === statusFilter
                )
                .map((task) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    updateMutation={updateMutation}
                    deleteMutation={deleteMutation}
                  />
                ))}

              {/* If No Completed Tasks Match the Filter */}
              {tasks
                .filter((task) => task.status === "completed")
                .filter(
                  (task) =>
                    task.title
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase()) ||
                    task.category
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase()) ||
                    task.priority
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase())
                )
                .filter((task) =>
                  statusFilter === "all"
                    ? true
                    : task.priority.toLowerCase() === statusFilter
                ).length === 0 && (
                <p>No completed tasks match your search or filter.</p>
              )}
            </div>
          )}

          {activeSection === "settings" && (
            <div className="settings-page">
              <h1 className="settings-title">⚙️ Account Settings</h1>

              {/* Display User Info */}
              <div className="account-info">
                <p>
                  <strong>Username:</strong>{" "}
                  {user?.username ? user.username : "N/A"}
                </p>
                <p>
                  <strong>Email:</strong> {user?.email ? user.email : "N/A"}
                </p>
              </div>

              {/* Change Username */}
              <div className="settings-section">
                <h3>🔄 Change Username</h3>
                <input
                  type="text"
                  placeholder="New Username"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  className="input-field"
                />
                <button onClick={handleChangeUsername} className="primary-btn">
                  Save Changes
                </button>
              </div>

              {/* Change Password */}
              <div className="settings-section">
                <br />
                <h3>🔒 Change Password</h3>
                <input
                  type="password"
                  placeholder="Current Password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="input-field"
                />
                <input
                  type="password"
                  placeholder="New Password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="input-field"
                />
                <button onClick={handleChangePassword} className="primary-btn">
                  Update Password
                </button>
              </div>

              {/* Delete Account */}
              <div className="settings-section">
                <br />{" "}
                <h3 className="text-red-600">
                  ⚠️ Do you want to delete your Account?
                </h3>
                <button
                  onClick={() => setShowDeleteModal(true)}
                  className="danger-btn"
                >
                  Delete My Account
                </button>
              </div>
              {/* Confirmation Modal for Deleting Account */}
              {showDeleteModal && (
                <div className="modal">
                  <div className="modal-content">
                    <h3 className="text-red-600">⚠️ Confirm Deletion</h3>
                    <p>
                      Are you sure you want to delete your account? This action
                      is permanent.
                    </p>
                    <div className="modal-actions">
                      <button
                        onClick={handleDeleteAccount}
                        className="danger-btn"
                      >
                        Yes, Delete
                      </button>
                      <button
                        onClick={() => setShowDeleteModal(false)}
                        className="cancel-btn"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeSection === "calendar" && (
            <CalendarComponent
              tasks={tasks}
              addTask={(task) => addMutation.mutate(task)}
            />
          )}
          {activeSection === "sketchpad" && <Sketchpad />}
        </main>
      </div>
    </DndProvider>
  );
}

export default TaskManager;
