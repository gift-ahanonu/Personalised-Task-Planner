const express = require("express");
const { Pool } = require("pg");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
require("dotenv").config();

const router = express.Router();
const db = new Pool({
  connectionString: process.env.DATABASE_URL,
  idleTimeoutMillis: 3000,
  connectionTimeoutMillis: 5000,
});

const uploadDir = path.join(__dirname, "../uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

// Configure Multer for file storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + uploads);
  },
});
const upload = multer({ storage });

// Middleware to Verify JWT
const authenticateUser = (req, res, next) => {
  try {
    const token = req.headers["authorization"]?.split(" ")[1];
    if (!token) return res.status(401).json({ message: "No token provided" });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded.user_id;
    next();
  } catch (error) {
    return res.status(401).json({ message: "Invalid token" });
  }
};

// Serve uploaded files
router.use("/uploads", express.static(uploadDir));

// Upload File Endpoint
router.post("/upload", authenticateUser, upload.single("file"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: "No file uploaded" });
  }
  res.json({ filePath: `/uploads/${req.file.filename}`, originalName: req.file.originalname });
});


router.post("/create", authenticateUser, async (req, res) => {
  let { title, description, deadline, category, priority, file } = req.body;

  if (!deadline) {
    deadline = null;
  }

  try {
    const newTask = await db.query(
      "INSERT INTO tasks (user_id, title, description, deadline, category, priority, file) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *",
      [req.user, title, description, deadline, category || "General", priority || "Medium", file || null]
    );

    res.status(201).json({ message: "Task added successfully", task: newTask.rows[0] });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});



// Get All Tasks for Logged-in User (Including File Paths)
router.get("/all", authenticateUser, async (req, res) => {
  try {
    const tasks = await db.query(
      "SELECT id, user_id, title, description, status, deadline, category, priority, file FROM tasks WHERE user_id = $1 ORDER BY created_at DESC",
      [req.user]
    );

    res.json(tasks.rows);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// Update Task
router.put("/update/:id", authenticateUser, async (req, res) => {
  const { title, description, status, deadline, file } = req.body;
  const { id } = req.params;

  try {
    const updatedTask = await db.query(
      "UPDATE tasks SET title = COALESCE($1, title), description = COALESCE($2, description), status = COALESCE($3, status), deadline = COALESCE($4, deadline), file = COALESCE($5, file) WHERE id = $6 AND user_id = $7 RETURNING *",
      [title, description, status, deadline, file, id, req.user]
    );

    if (updatedTask.rows.length === 0) {
      return res.status(404).json({ message: "Task not found or not authorized" });
    }

    res.json({ message: "Task updated successfully", task: updatedTask.rows[0] });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// Delete Task
router.delete("/delete/:id", authenticateUser, async (req, res) => {
  const { id } = req.params;

  try {
    const deletedTask = await db.query("DELETE FROM tasks WHERE id = $1 AND user_id = $2 RETURNING *", [id, req.user]);

    if (deletedTask.rows.length === 0) {
      return res.status(404).json({ message: "Task not found or not authorized" });
    }

    res.json({ message: "Task deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});


// Serve Uploaded Files Publicly
router.use("/uploads", express.static(uploadDir));

module.exports = router;
