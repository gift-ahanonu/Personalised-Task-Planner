const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Pool } = require("pg");
require("dotenv").config();

const router = express.Router();

// Database Connection
const db = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Register a New User
router.post("/register", async (req, res) => {
  const { username, email, password } = req.body;

  try {
    // Check if user already exists
    const userExists = await db.query("SELECT * FROM users WHERE email = $1", [email]);
    if (userExists.rows.length > 0) {
      return res.status(400).json({ message: "User already exists. Please log in." });
    }

    // Hash Password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert New User into Database
    const newUser = await db.query(
      "INSERT INTO users (username, email, password_hash) VALUES ($1, $2, $3) RETURNING id, username, email",
      [username, email, hashedPassword]
    );

    // Instead of returning a token, return success message
    res.status(201).json({ message: "Registration successful. Please log in." });

  } catch (error) {
    console.error(" Registration Error:", error);
    res.status(500).json({ message: "Server error" });
  }
});
// User Login
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    // Check if user exists
    const user = await db.query("SELECT * FROM users WHERE email = $1", [email]);
    if (user.rows.length === 0) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Compare password
    const validPassword = await bcrypt.compare(password, user.rows[0].password_hash);
    if (!validPassword) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Generate JWT Token
    const token = jwt.sign({ user_id: user.rows[0].id }, process.env.JWT_SECRET, { expiresIn: "1h" });

    res.json({ token, user: { id: user.rows[0].id, username: user.rows[0].username, email: user.rows[0].email } });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});


// Middleware to Verify JWT
const authenticateUser = (req, res, next) => {
  try {
    const token = req.headers["authorization"]?.split(" ")[1];
    if (!token) return res.status(401).json({ message: "No token provided" });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded.user_id; 
    next();
  } catch (error) {
    return res.status(401).json({ message: "Invalid token" });
  }
};


// Get All Users
router.get("/users", async (req, res) => {
  try {
    const users = await db.query("SELECT id, username, email FROM users");
    res.json(users.rows);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// Get Logged-in User Data
router.get("/me", authenticateUser, async (req, res) => {
  try {
    const user = await db.query("SELECT id, username, email FROM users WHERE id = $1", [req.user]);

    if (user.rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json(user.rows[0]);
  } catch (error) {
    console.error("❌ Error fetching user:", error.message);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});


router.put("/update-username", authenticateUser, async (req, res) => {
  const { newUsername } = req.body;

  try {
    const updatedUser = await db.query(
      "UPDATE users SET username = $1 WHERE id = $2 RETURNING id, username, email",
      [newUsername, req.user]
    );

    if (updatedUser.rows.length === 0) return res.status(404).json({ message: "User not found" });

    res.json({ message: " Username updated successfully!", user: updatedUser.rows[0] });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});


router.put("/update-password", authenticateUser, async (req, res) => {
  const { currentPassword, newPassword } = req.body;

  try {
    const user = await db.query("SELECT password_hash FROM users WHERE id = $1", [req.user]);

    const validPassword = await bcrypt.compare(currentPassword, user.rows[0].password_hash);
    if (!validPassword) return res.status(400).json({ message: "Incorrect current password" });

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);
    await db.query("UPDATE users SET password_hash = $1 WHERE id = $2", [hashedNewPassword, req.user]);

    res.json({ message: " Password updated successfully!" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

router.delete("/delete", authenticateUser, async (req, res) => {
  try {
    await db.query("DELETE FROM users WHERE id = $1", [req.user]);
    res.json({ message: " Account deleted successfully!" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

//  Get Logged-in User Data
router.get("/me", async (req, res) => {
  try {
    const authHeader = req.headers["authorization"];
    if (!authHeader) {
      return res.status(401).json({ message: "No token provided" });
    }

    const token = authHeader.split(" ")[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Fetch user from database
    const user = await db.query("SELECT id, username, email FROM users WHERE id = $1", [decoded.user_id]);

    if (user.rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json(user.rows[0]); 
  } catch (error) {
    console.error("Error fetching user:", error.message);
    res.status(401).json({ message: "Invalid token" });
  }
});

// Delete User Account 
router.delete("/delete", authenticateUser, async (req, res) => {
  try {
    //  Delete all tasks associated with the user
    await db.query("DELETE FROM tasks WHERE user_id = $1", [req.user]);

    // Delete user account
    const deletedUser = await db.query("DELETE FROM users WHERE id = $1 RETURNING *", [req.user]);

    if (deletedUser.rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ message: "Account deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});



module.exports = router;
