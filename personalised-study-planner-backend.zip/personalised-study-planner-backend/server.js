require("dotenv").config();
const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const sharp = require("sharp");
const jwt = require("jsonwebtoken");

const app = express();

// Middleware
app.use(cors({
  origin: "http://localhost:5173", // Used to allow requests from frontend
  methods: ["GET", "POST", "PUT", "DELETE"],
  allowedHeaders: ["Content-Type", "Authorization"],
}));
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "uploads")));



// Database Connection
const db = new Pool({
  connectionString: process.env.DATABASE_URL,
  idleTimeoutMillis: 3000,
  connectionTimeoutMillis: 5000,
});

db.connect()
  .then(() => console.log(" Connected to PostgreSQL"))
  .catch((err) => console.error("❌ Database connection error:", err.message));

// Ensure Uploads Directory Exists
const uploadDir = path.join(__dirname, "uploads");
const sketchDir = path.join(uploadDir, "sketches");

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}
if (!fs.existsSync(sketchDir)) {
  fs.mkdirSync(sketchDir);
}

// Middleware to Verify JWT for Authentication
const authenticateUser = (req, res, next) => {
  try {
    const token = req.headers["authorization"]?.split(" ")[1];
    if (!token) return res.status(401).json({ message: "No token provided" });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded.user_id;
    next();
  } catch (error) {
    return res.status(401).json({ message: "Invalid token" });
  }
};

// Configure Multer for Task File Uploads
const taskStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const taskUpload = multer({ storage: taskStorage });

// API Route to Handle Task File Uploads
app.post("/tasks/upload", authenticateUser, taskUpload.single("file"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: "No file uploaded" });
  }
  res.json({
    filePath: `/uploads/${req.file.filename}`,
    originalName: req.file.originalname,
  });
});



app.get("/uploads/:filename", (req, res) => {
  const filePath = path.join(__dirname, "uploads", req.params.filename);
  res.download(filePath); // Forces file download
});


// Default Route
app.get("/", (req, res) => {
  res.send(" Backend is running...");
});

// Import and Use Routes
const authRoutes = require("./routes/auth");
const taskRoutes = require("./routes/tasks");
app.use("/auth", authRoutes);
app.use("/tasks", taskRoutes);

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server is running on port ${PORT}`);
});
